# Compiler and flags
CXX = g++
CXXFLAGS = -std=c++11 -O2

# Source file
SRC = pi_serial.cpp

# Target file
TARGET = pi_serial.out

# Compile the program
all: $(TARGET)

# Create the executable
$(TARGET): $(SRC)
	$(CXX) $(CXXFLAGS) -o $(TARGET) $(SRC)

# Clean rule to remove the executable
clean:
	rm -f $(TARGET)