#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

int main() {
    int number_of_tosses = 1000000;
    int number_in_circle = 0;
    double x, y, distance_squared;

    srand(time(0));

    for (int toss = 0; toss < number_of_tosses; toss++) {
        x = (double)rand() / RAND_MAX * 2.0 - 1.0;  // Random x between -1 and 1
        y = (double)rand() / RAND_MAX * 2.0 - 1.0;  // Random y between -1 and 1
        distance_squared = x * x + y * y;
        if (distance_squared <= 1) number_in_circle++;
    }

    // Estimate Pi
    double pi = 4.0 * number_in_circle / number_of_tosses;
    cout << pi << endl;

    return 0;
}

/*
#include <iostream>
#include <pthread.h>
#include <random>
#include <cstdlib>
#include <ctime>

long long number_of_tosses;
long long number_in_circle = 0;
pthread_mutex_t mutex;

void* Pthread_monte_carlo(void* thread_tosses) {
    long long tosses = *(long long*)thread_tosses;
    long long local_in_circle = 0;

    // 生成一個基於 current time 和 thread ID 的 random seed
    // 保證每個 thread 的 random seed 是獨立的
    unsigned int seed = time(NULL) ^ pthread_self(); 
    for (long long toss = 0; toss < tosses; toss++) {
        // rand_r 生成 thread safety 的 random number，使用每個 thread 的 seed 來避免競爭
        double x = rand_r(&seed) / (double)RAND_MAX * 2.0 - 1.0;
        double y = rand_r(&seed) / (double)RAND_MAX * 2.0 - 1.0;
        double distance_squared = x * x + y * y;
        if (distance_squared <= 1.0) {
            local_in_circle++;
        }
    }

    // Because number_in_circle is global variable
    pthread_mutex_lock(&mutex);
    number_in_circle += local_in_circle;
    pthread_mutex_unlock(&mutex);

    return NULL;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <number_of_threads> <number_of_tosses>\n";
        return -1;
    }
    // argv[0] = ./pi.out
    // argv[1] = 6 
    // argv[2] = 1000000000
    int number_of_threads = std::atoi(argv[1]);
    number_of_tosses = std::atoll(argv[2]);

    pthread_t threads[number_of_threads];
    long long tosses_per_thread = number_of_tosses / number_of_threads;

    pthread_mutex_init(&mutex, NULL);

    // Create threads
    for (int i = 0; i < number_of_threads; i++) {
        pthread_create(&threads[i], NULL, Pthread_monte_carlo, &tosses_per_thread);
    }

    // 等待所有 threads  完成
    for (int i = 0; i < number_of_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    // 計算 PI
    double PI = 4.0 * number_in_circle / ((double)number_of_tosses);
    std::cout.precision(7);
    std::cout << PI << std::endl;

    pthread_mutex_destroy(&mutex);

    return 0;
}

*/

/*
# Compiler and flags
CXX = g++
CXXFLAGS = -std=c++11 -pthread -O2

# Source file
SRC = pi.cpp

# Target file
TARGET = pi.out

# Compile the program
all: $(TARGET)

# Create the executable
$(TARGET): $(SRC)
	$(CXX) $(CXXFLAGS) -o $(TARGET) $(SRC)

# Clean rule to remove the executable
clean:
	rm -f $(TARGET)
*/