// Define vector unit width here
#define VECTOR_WIDTH 16
#define EXP_MAX 10
